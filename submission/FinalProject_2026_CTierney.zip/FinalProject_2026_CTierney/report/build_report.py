"""Plan Step 8: build report/FinalProject_2026_CTierney.docx and .pdf.

Every result number is read from experiments/*.csv at build time (no hand-typed results). Body text is Times New
Roman 12 pt, single spaced, single column; tables and captions are Times New Roman 10 pt. The PDF is produced by
Microsoft Word (COM, through PowerShell), and the body page count (excluding cover and references) is checked.
Run: python report/build_report.py
"""
import os
import re
import subprocess
import sys

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "analysis"))
import reference_model as rm  # noqa: E402

EXP, FIG = os.path.join(ROOT, "experiments"), os.path.join(ROOT, "figures")
OUT = os.path.join(HERE, "FinalProject_2026_CTierney")
FONT = "Times New Roman"

# ------------------------------------------------------------------ numbers from the CSVs
P = rm.load_params()
S = pd.read_csv(os.path.join(EXP, "summary_runs.csv"))
TH = pd.read_csv(os.path.join(EXP, "thresholds.csv"))
SENS = pd.read_csv(os.path.join(EXP, "sensitivity_results.csv"))
LHS = pd.read_csv(os.path.join(EXP, "sensitivity_lhs.csv"))
CNT = pd.read_csv(os.path.join(EXP, "validation_counties.csv"))
TSC = pd.read_csv(os.path.join(EXP, "validation_timestep_change.csv"))
EXT = pd.read_csv(os.path.join(EXP, "validation_extreme.csv"))
PT = pd.read_csv(os.path.join(ROOT, "data", "parameters.csv"))


def run(exp, **kw):
    q = S[S.experiment == exp]
    for k, v in kw.items():
        q = q[q[k] == v]
    assert len(q) == 1, (exp, kw, len(q))
    return q.iloc[0]


def th(kind, cond_prefix):
    q = TH[(TH.kind == kind) & (TH.condition.str.startswith(cond_prefix))]
    return float(q.value.iloc[0])


E0, E1 = run("E0"), run("E1")
E2 = S[S.experiment == "E2"].sort_values("size-mw")
E3 = S[S.experiment == "E3"].sort_values("t-sign")
E4 = S[S.experiment == "E4"]
E9 = S[S.experiment == "E9"]
on9 = E9[E9["links-on?"] == True].set_index(["size-mw", "t-sign"])  # noqa: E712
off9 = E9[E9["links-on?"] == False].set_index(["size-mw", "t-sign"])  # noqa: E712
d90 = on9.t90 - off9.t90
dF = (off9.F20 - on9.F20) / off9.F20
e1ts = pd.read_csv(os.path.join(EXP, "E1_results.csv"))
nb_first_pos = e1ts[(e1ts.ticks > 3) & (e1ts["net-benefit"] > 0)].ticks.min()
nb_min = e1ts["net-benefit"].min()
HH20 = e1ts.population.iloc[-1] / P["hh_size"]
fiscal_hh20 = 1e6 * (E1.rev20 - P["svc_cost_per_MW"] * E1.E20 - P["percap_cost"] * 0) / HH20
ql20 = P["ql_cost"] * E1.E20 / 1000 * E1.O20
house20 = E1.hx20 * P["house_cost_base"]
elec20 = (E1.RI_max - 1) * P["elec_price"] / 100 * P["hh_kwh"]
worst_ts = TSC.change_0125_vs_00625.max()
lhs_pos = (LHS.cum_nb > 0).mean()
top_assump = list(SENS[SENS.assumption].parameter.head(8))
flips = list(SENS[SENS.cum_nb_sign_flip].parameter)
r = lambda x, n=0: ("{:,.%df}" % n).format(x)  # noqa: E731

F = dict(
    sail=P["size_sail"], t90=E1.t90, rev20=E1.rev20, F20=E1.F20, RI=E1.RI_max, ws=E1.stress_peak, ws0=E0.stress_peak, hx=100 * E1.hx20,
    Opk=E1.O_peak, O20=E1.O20, mmin=E1.m_min, cum=E1.cum_nb, cummin=E1.cum_nb_min, payback=E1.payback_year, nb20=E1.nb20,
    nbpos=nb_first_pos, nbmin=nb_min,
)

# ------------------------------------------------------------------ document helpers
doc = Document()
for s in doc.sections:
    s.left_margin = s.right_margin = s.top_margin = s.bottom_margin = Inches(1)
st = doc.styles["Normal"]
st.font.name = FONT
st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
pf = st.paragraph_format
pf.space_before, pf.space_after, pf.line_spacing = Pt(0), Pt(6), 1.0
for name, size in (("Heading 1", 14), ("Heading 2", 12), ("Title", 20)):
    h = doc.styles[name]
    h.font.name, h.font.size, h.font.bold, h.font.color.rgb = FONT, Pt(size), True, RGBColor(0, 0, 0)
    h.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    h.element.rPr.rFonts.set(qn("w:ascii"), FONT)
    h.element.rPr.rFonts.set(qn("w:hAnsi"), FONT)
    for att in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        h.element.rPr.rFonts.attrib.pop(qn(att), None)
    h.paragraph_format.space_before, h.paragraph_format.space_after = Pt(10 if size > 12 else 6), Pt(4)
    h.paragraph_format.keep_with_next = True
for name in ("List Bullet",):
    doc.styles[name].font.name = FONT
    doc.styles[name].font.size = Pt(12)
    doc.styles[name].paragraph_format.space_after = Pt(2)


def runs(par, text, size=None, italic=False):
    for i, part in enumerate(re.split(r"\*\*", text)):
        if not part:
            continue
        rr = par.add_run(part)
        rr.bold = i % 2 == 1
        rr.italic = italic
        rr.font.name = FONT
        if size:
            rr.font.size = Pt(size)


def H1(t):
    doc.add_heading(t, level=1)


def H2(t):
    doc.add_heading(t, level=2)


def Pp(t):
    p = doc.add_paragraph()
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    runs(p, t)


def B(items):
    for t in items:
        p = doc.add_paragraph(style="List Bullet")
        runs(p, t)


def caption(t):
    p = doc.add_paragraph()
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(8)
    runs(p, t, size=10, italic=True)


def FIGR(name, width, cap):
    p = doc.add_paragraph()
    p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_after = Pt(2)
    p.add_run().add_picture(os.path.join(FIG, name), width=Inches(width))
    caption(cap)


def FIG2(a, b, wa, wb, cap):
    t = doc.add_table(rows=1, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for cell, name, w in zip(t.rows[0].cells, (a, b), (wa, wb)):
        q = cell.paragraphs[0]
        q.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
        q.paragraph_format.space_after = Pt(0)
        q.add_run().add_picture(os.path.join(FIG, name), width=Inches(w))
        cell.width = Inches(w + 0.05)
    caption(cap)


def T(header, rows, cap, widths=None):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        runs(c.paragraphs[0], "**%s**" % h, size=10)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            runs(cells[i].paragraphs[0], str(v), size=10)
    for row in t.rows:
        for c in row.cells:
            c.paragraphs[0].paragraph_format.space_after = Pt(0)
    if widths:
        for row in t.rows:
            for c, w in zip(row.cells, widths):
                c.width = Inches(w)
    caption(cap)


def pagebreak():
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


# ------------------------------------------------------------------ cover
for _ in range(6):
    doc.add_paragraph()
p = doc.add_paragraph(style="Title")
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run("Data Centers and a Growing County: A System Dynamics Model of Development in Coweta County, Georgia")
for line in ["", "CSC 8840 Final Project, Option 2 (System Dynamics)", "Fall 2026", "", "Carter Tierney", "",
             "Instructor: Dr. Xiaolin Hu", "Georgia State University", "", "Submitted December 2026"]:
    q = doc.add_paragraph()
    q.alignment = WD_ALIGN_PARAGRAPH.CENTER
    runs(q, line)
pagebreak()

# ------------------------------------------------------------------ 1 problem statement
H1("1. Problem Statement")
Pp("Large data centers are arriving in fast-growing suburban and rural counties around Atlanta. They promise large property tax payments, "
   "but they also need very large amounts of electricity, can need large amounts of water, bring years of construction, and often face organized "
   "local opposition. Coweta County approved its first hyperscale campus, Project Sail, in April 2026 by a 3-2 vote, and several larger proposals "
   "are in the pipeline. Residents, commissioners and utilities therefore face a practical question that a single spreadsheet cannot answer well: "
   "**when the grid, water, fiscal and community effects interact over time, is data center development a net benefit or a net cost to residents, "
   "and what choices change the answer?**")
Pp("This project builds and validates a system dynamics model of that question in the NetLogo 7 System Dynamics Modeler. The model links four sectors "
   "(electricity and grid, water, county finance, and population, housing and opposition) over a 20-year horizon. It is used to measure how "
   "build-out size and speed change rates, water stress, finances and housing; to find the conditions under which development is a net benefit or "
   "a net cost; to compare policy choices (cooling technology, who pays for grid upgrades, tax abatement, drought); and to measure how much the "
   "cross-sector opposition feedback matters.")

# ------------------------------------------------------------------ 2 system
H1("2. General Description of the System")
Pp("Coweta County is about 40 miles southwest of Atlanta, with an estimated 160,240 residents in 2025, up from 158,233 in 2024 [1]. "
   "Its water comes mainly from the Coweta County Water and Sewerage Authority, which holds a 27 MGD Chattahoochee River withdrawal permit and "
   "is building a new intake with an initial design capacity of 21 MGD [2]. Electricity is supplied by Georgia Power under rules set by the Georgia "
   "Public Service Commission (PSC). In January 2025 the PSC adopted a rule that lets Georgia Power bill new customers above 100 MW under special "
   "terms so that they cover the generation and transmission built for them [3].")
Pp("**Project Sail** (the base case) is a Prologis campus of nine buildings on about 830 acres near Sargent, designed for about 900 MW "
   "(the March 2026 fact sheet gives 910 MW) with closed-loop air cooling and about 300,000 gallons per day of water at full build-out [4]. "
   "The developer's fiscal impact analysis models nine buildings coming online over nine years, a 10-year phased personal property abatement, and "
   "county plus school revenue that averages about $86 million per year over the period [5]; Prologis's latest projection is about $100 million per "
   "year at full build-out [6]. The January 2025 version of the project (936 MW, evaporative cooling) would have used about 9 MGD at peak [7], "
   "which gives a useful high-water comparison. Residents filed a Superior Court appeal in May 2026 [8], and a referendum petition collected "
   "thousands of signatures toward the roughly 14,000 needed; its ballot status could not be confirmed [9].")
Pp("Three other proposals define the larger growth scenarios: **Bridgeport** (about 1,500 MW in its revised plan [10]), **Project Pegasus** "
   "(size not published, so 400 MW is assumed), and **Project Peach** (700 MW [11], whose rezoning was reverted in October 2026). Together with "
   "Sail they give scenarios of 900 MW, 2,800 MW and 3,500 MW. Metro Atlanta counties that already host data centers provide comparison points: "
   "in Douglas County data centers reportedly paid about 5% of general fund revenue over 2023-2025 (3%, 4% and 8% by year; the source labels "
   "these figures unverified) [12], and in Newton County Meta's campus uses about 10% of the county's daily water, according to the water "
   "authority's director [13].")
Pp("The system boundary is the county's residents. The model tracks what reaches them: local tax revenue net of abatement and of the public "
   "cost of new residents, the share of grid costs that reaches residential electricity rates, water stress and its cost, housing cost pressure, "
   "and a quality-of-life cost of large campuses that grows with community opposition. Regional power markets, state tax policy and the "
   "national data center market are outside the boundary and enter only as scenario inputs.")

# ------------------------------------------------------------------ 3 goals
H1("3. Goals of the Modeling and Simulation Study")
B(["**Goal 1.** Measure how the size and speed of data center build-out change residential electricity rates, water stress, county finances and housing costs.",
   "**Goal 2.** Identify the conditions under which data center development is a net benefit or a net cost to residents.",
   "**Goal 3.** Compare policy experiments: build-out size and speed, cooling technology (closed-loop versus evaporative), who pays for grid upgrades (ratepayers versus data centers), tax abatement level, and a drought scenario.",
   "**Goal 4.** Measure how much cross-sector feedback matters by running the model with the opposition links switched off and on.",
   "**Goal 5.** Validate the model with dimensional consistency checks, extreme-condition tests, a time-step test, comparison with metro Atlanta counties that host data centers, and sensitivity analysis."])
Pp("Goals 1 to 5 are the same five goals as in the approved proposal. Each experiment in Section 5 maps to one or more of them.")

# ------------------------------------------------------------------ 4 model
H1("4. The Simulation Model")
H2("4.1 Structure")
Pp("The model has the six stocks named in the proposal: energized data center capacity E (MW), grid capacity added for data centers G (MW), "
   "water supply capacity W (MGD), cumulative county net fiscal impact F ($ million), population P and community opposition O (0 to 1). "
   "It also has one supporting stock, contracted load C (MW), which is needed so that grid capacity can follow contracted load after a delay "
   "and so that opposition has a signing rate to slow, and one accounting stock that integrates the net benefit indicator. The three "
   "auxiliaries from the proposal are water stress, the electricity rate index and the housing cost index. Figure 1 shows the causal loop "
   "diagram with the four loops; Figure 2 shows the stock-and-flow structure as drawn by the NetLogo System Dynamics Modeler.")
FIGR("causal_loop.png", 5.2, "Figure 1. Causal loop diagram. R1 (reinforcing): tax revenue funds property tax relief, lowering opposition and speeding build-out. "
     "B1: grid capacity follows contracted load after a delay and caps energization. B2: water stress triggers supply expansion after a delay. "
     "B3: construction, water stress, rates and housing costs raise opposition, which slows permitting.")
FIGR("sd_modeler.png", 4.7, "Figure 2. The stock-and-flow diagram in the NetLogo 7 System Dynamics Modeler (8 stocks, 8 flows, 38 converters).")
H2("4.2 Explanation of Operation")
B(["**Electricity and grid (B1).** Load is signed at rate S/t_sign, multiplied by a permitting factor m that falls as opposition rises. Grid capacity follows contracted load with a first-order delay D_grid = 2 years, and energized load follows grid capacity with tau = 1 year, so E can never exceed G. The annual cost of new grid capacity (G x $1.2M/MW x 10% carrying charge) reaches residential rates in proportion to a payer share: 5% when data centers pay under the PSC rule, 60% when costs are socialized.",
   "**Water (B2).** Demand is baseline demand (growing with population) plus E times a water intensity: 0.00033 MGD/MW for Sail's closed-loop design and 0.00962 MGD/MW for the 2025 evaporative design. Water stress is demand over effective capacity. A drought removes 30% of capacity for two years from year 8. When structural stress passes 0.85, capacity expands toward a stress of 0.80 after a 5-year delay, capped at the 27 MGD permit.",
   "**County finance (R1).** Gross revenue is $0.1115M per MW per year (derived from the developer's fiscal analysis), reduced by an abatement that starts at 90.7% and fades linearly to zero over 16.1 years (fitted to the same schedule). Costs are services per MW and the public cost of residents above the no-data-center path. 20% of net revenue is returned as property tax relief, which lowers opposition.",
   "**Population, housing and opposition (B3).** Each MW brings about 0.54 residents through direct and induced jobs. The housing index rises with population and with a proximity premium per GW of campus; housing cost above the baseline path slows in-migration. Opposition moves toward a target set by construction under way, water stress above 0.8, rate increases, housing excess, minus relief, with a 2-year adjustment time. The switch links-on? cuts opposition's effect on permitting (Goal 4)."])
Pp("The **net benefit indicator** is defined once and used everywhere. In dollars per household per year, relative to the no-data-center baseline, "
   "it is net public revenue per household (returned as relief or retained), minus the extra electricity bill, minus the housing cost excess "
   "valued at $16,000 per household per year, minus a water shortage penalty for stress above 1 beyond what the baseline would suffer, minus a "
   "quality-of-life cost of $1,500 per household per year per GW of campus at full opposition. Cumulative net benefit is the undiscounted 20-year sum. "
   "The weights are judgement values, labeled ASSUMPTION, and tested in Section 6.")
H2("4.3 Illustrative Model Code")
Pp("The model is generated from a single specification by a Python script, so that the NetLogo file, an independent Python reference implementation "
   "and this report all share one set of equations and one parameter table. The core of each time step (Euler integration, dt = 0.125 year) is:")
code = "\n".join([
    "m       = clip((1 - s_perm*O)/(1 - s_perm*O0), 0, m_max)    ; permitting (B3)",
    "sign    = min(S/t_sign*m, (S - C)/dt)                       ; MW/yr signed",
    "dG/dt   = (C - G)/D_grid;  dE/dt = (G - E)/tau_e            ; delays (B1)",
    "RI      = 1 + share*G*cost_per_MW*carry/resid_rev           ; rate index",
    "stress  = (base0*P/P0 + E*wi)/(W*(1 - sev*drought))         ; water (B2)",
    "rev_net = rev_per_MW*E*(1 - abate0*max(0, 1 - t/T_abate))",
    "dF/dt   = rev_net - relief - svc*E - percap*(P - P_base)",
    "D       = d0 + a_c*(C-E)/1000 + a_w*max(0, stress-0.8)",
    "          + a_e*(RI-1)/0.1 + a_h*hx - a_r*relief/levy",
    "dO/dt   = (D/(1+D) - O)/tau_O                               ; O in [0,1)",
    "nb      = fiscal_hh - elec_hh - house_hh - water_hh - ql_cost*(E/1000)*O"])
p = doc.add_paragraph()
rr = p.add_run(code)
rr.font.name, rr.font.size = "Courier New", Pt(9)
caption("Listing 1. Pseudo code of one Euler step (the full equations are in notes/model_spec.md).")
H2("4.4 Parameters")
rows = [("Sail size", "900 MW", "proposal; fact sheet 910 MW [4]"), ("Revenue per MW", "$0.1115M/yr", "derived from EIG fiscal analysis [5]"),
        ("Initial abatement / fade", "90.7% / 16.1 yr", "fitted to [5]"), ("Water intensity closed / evap", "0.00033 / 0.00962 MGD/MW", "[4], [7]"),
        ("Water permit / initial capacity", "27 / 21 MGD", "[2]"), ("Population 2025, growth", "160,240; 1.27%/yr", "[1]"),
        ("Grid delay, energize delay", "2 yr, 1 yr", "ASSUMPTION calibrated to 9-year build-out [5]"),
        ("Grid cost share to residents", "5% (DC pays) / 60%", "ASSUMPTION informed by PSC rule [3]"),
        ("Initial opposition O0", "0.40", "ASSUMPTION (3-2 vote, petition [9])"), ("Quality-of-life cost ql_cost", "$1,500/hh/yr per GW", "ASSUMPTION (value judgement)"),
        ("Housing proximity premium k_prox", "2% per GW", "ASSUMPTION")]
T(["Parameter", "Value", "Source"], rows, "Table 1. Key parameters. All %d constants, units, ranges and sources are in data/parameters.csv; %d are labeled ASSUMPTION (fully or partly)." % (len(PT), PT.source.str.contains("ASSUMPTION").sum()), widths=[2.2, 1.8, 2.5])
H2("4.5 Implementation and Verification")
Pp("The NetLogo model (model/DataCenterSD.nlogox) is written by model/build_nlogox.py in the System Dynamics Modeler format, with every constant "
   "exposed as a slider so that BehaviorSpace can vary it. An independent Python implementation of the same specification serves as a test oracle. "
   "Across eight scenarios (base, feedback off, evaporative with drought, ratepayers pay, full abatement, 3,500 MW fast, 3,500 MW stress, zero build) "
   "the two agree on every stock at year 20 to a worst relative difference of 5 x 10^-12, and on the full time series. Six hand-derived tests of the "
   "reference model pass, for example that zero build-out reproduces the baseline and that full Sail build-out gives about $100 million per year. "
   "A full 20-year run finishes in seconds, well inside the one-minute demo target.")
H2("4.6 Simulation Snapshots")
FIG2("snapshot_1.png", "snapshot_2.png", 3.2, 3.2, "Figure 3. NetLogo interface at year 20. Left: configuration 1 (Project Sail base case; scenario controls on the left, monitors and six plots in the middle, parameter sliders on the right). "
     "Right: configuration 2 (3,500 MW, evaporative cooling, drought): water stress passes 1, opposition rises to 0.77 and net benefit turns negative.")

# ------------------------------------------------------------------ 5 experimental design
H1("5. Experimental Design")
Pp("The model is deterministic, so every setting is run once. All experiments are BehaviorSpace setups run headless in NetLogo 7.0.4 "
   "(experiments/E*.xml) and record every stock and indicator at every time step (161 rows per run). Each experiment changes one family of inputs "
   "from the base case (Sail, 900 MW, t-sign 5, closed-loop cooling, data centers pay, EIG abatement, no drought, feedback on). Validation (Goal 5) "
   "was completed and passed before any of these were run. Because the model and its Python twin agree to 10^-12, break-even values were located "
   "by root finding on the Python model and then confirmed in NetLogo.")
rows = [("E0", "no data centers (baseline)", "1", "reference for all"), ("E1", "Project Sail base case", "1", "1, 2"),
        ("E2", "size 0, 450, 900, 1,800, 2,800, 3,500 MW", "6", "1, 2, 3"), ("E3", "speed: t-sign 3, 5, 10, 15, 20 yr", "5", "1, 3"),
        ("E4", "size (7) x speed (7) grid", "49", "1, 2"), ("E5", "cooling x drought at 900 and 3,500 MW", "8", "3"),
        ("E6", "grid payer at 900 and 3,500 MW", "4", "3"), ("E7", "abatement 0, 25, 50, 75, 100% at 900 and 3,500 MW", "10", "3"),
        ("E8", "best and worst policy combinations, with and without drought", "8", "2, 3"), ("E9", "feedback on/off x 4 sizes x 3 speeds", "24", "4"),
        ("E10", "top 4 ASSUMPTION parameters (low/base/high) x 14 sizes", "168", "2, 5"),
        ("V", "units audit, 10 extreme tests, dt test, county comparison, sensitivity", "about 1,000", "5")]
T(["ID", "Design", "Runs", "Goals"], rows, "Table 2. Experiments and the goals they serve.", widths=[0.5, 3.9, 0.8, 1.0])
Pp("The main outputs are year-20 energized MW and the year 90% is energized, the peak electricity rate index, peak water stress, the housing cost "
   "excess over the baseline, cumulative net fiscal impact, peak and final opposition, the minimum permitting factor, and 20-year cumulative net "
   "benefit per household. A net benefit threshold is a value of a control or parameter at which cumulative net benefit crosses zero.")

# ------------------------------------------------------------------ 6 results
H1("6. Simulation Results and Analysis")
H2("6.1 Validation (Goal 5)")
ext_pass = (EXT.result == "PASS").sum()
c = CNT.set_index("metric")
Pp("All validation tests passed before the experiments were run (experiments/validation_log.md):")
B(["**Dimensional consistency:** every equation was audited; the only conversions ($M to $, MW to GW, cents to dollars) are explicit.",
   "**Extreme conditions (%d of %d pass, in NetLogo):** zero build-out reproduces the baseline; a 9,000 MW build-out keeps E <= G <= C <= size and opposition below 1; "
   "near-zero water capacity gives high but finite stress while supply expands to the permit cap; 0%% abatement returns gross revenue exactly and 100%% returns none; "
   "opposition forced toward 1 drives the permitting factor to 0 and stalls signing at 22 MW; one-step delays stay monotone; 1,000-year delays energize almost nothing." % (ext_pass, len(EXT)),
   "**Time step:** halving dt from 0.125 to 0.0625 changes no year-20 output by more than %.2f%% in the base, 3,500 MW fast and stress scenarios (criterion 2%%), so dt = 0.125 is kept." % (100 * worst_ts),
   "**Comparison counties:** the model's county share of Sail revenue is %s of the county budget at year 10 and %s at year 20, inside Douglas County's observed 3-8%% [12]. "
   "The data center share of county water is %s with closed-loop cooling and %s with evaporative cooling, bracketing Newton County's 10%% [13]. "
   "No comparison county publishes rate or housing effects, so those rest on tested assumptions." % (
       c.loc["county share of DC revenue / county budget, year 10"].model, c.loc["county share of DC revenue / county budget, year 20"].model,
       c.loc["DC share of county water demand, year 20 (closed-loop)"].model, c.loc["DC share of county water demand, year 20 (evaporative)"].model),
   "**Sensitivity:** see Section 6.6."])
H2("6.2 Base Case: Project Sail")
FIGR("base_timeseries.png", 5.7, "Figure 4. Base case time series (NetLogo E1) against the no-data-center baseline (E0).")
Pp("Figure 4 shows the base case. Load is signed over about six years, grid capacity follows two years behind, and 90%% of the 900 MW is energized "
   "by year %.2f, matching the developer's nine-year schedule. Net data center revenue reaches $%.1f million per year at year 20 and cumulative net fiscal "
   "impact $%s million. Because data centers pay for their grid under the PSC rule, the rate index peaks at only %.4f (about $%.0f per household per year). "
   "Closed-loop cooling raises peak water stress only from %.3f to %.3f. Housing costs end %.1f%% above the baseline path. Opposition climbs from 0.40 to "
   "%.2f during construction, which slows permitting (factor down to %.2f), then falls to %.2f as tax relief arrives (loop R1)." % (
       F["t90"], F["rev20"], r(F["F20"]), F["RI"], elec20, F["ws0"], F["ws"], F["hx"], F["Opk"], F["mmin"], F["O20"]))
Pp("Net benefit per household is negative early: it bottoms at about $%.0f per year around year 6, because construction disruption and opposition "
   "arrive while most revenue is still abated. It turns positive at year %.0f and reaches $%.0f per year by year 20. The cumulative total bottoms at "
   "$%s and is positive for good from year %.1f, ending at **+$%s per household over 20 years**. In year 20 the fiscal term (about $%s) outweighs the "
   "quality-of-life term (about $%.0f) and housing (about $%.0f)." % (
       F["nbmin"], F["nbpos"], F["nb20"], r(F["cummin"]), F["payback"], r(F["cum"]), r(fiscal_hh20), ql20, house20))
H2("6.3 Effect of Size and Speed (Goal 1)")
rows = [("%.0f" % x["size-mw"], "n/a" if pd.isna(x.t90) else "%.2f" % x.t90, "%.4f" % x.RI_max, "%.3f" % x.stress_peak, "%.1f%%" % (100 * x.hx20),
         r(x.F20), "%.2f" % x.O_peak, r(x.cum_nb)) for _, x in E2.iterrows()]
T(["Size (MW)", "90% energized (yr)", "Rate index", "Peak water stress", "Housing excess", "Net fiscal ($M)", "Peak opposition", "Cum. net benefit ($/hh)"],
  rows, "Table 3. E2, effect of build-out size (closed-loop cooling, data centers pay).")
nz = E2[E2["size-mw"] > 0]
slope = lambda col: np.polyfit(nz["size-mw"] / 1000, nz[col], 1)[0]  # noqa: E731
Pp("With closed-loop cooling and data centers paying for the grid, every impact scales almost linearly with size (Table 3). Per additional 1,000 MW, "
   "the rate index rises by %.4f, peak water stress by %.3f, the housing excess by %.1f points and net fiscal impact by $%s million. Larger campuses take "
   "longer to energize (year %.1f at 3,500 MW) because opposition slows permitting, and their peak opposition is higher (%.2f), but tax relief also pulls "
   "their final opposition lower." % (slope("RI_max"), slope("stress_peak"), 100 * slope("hx20"), r(slope("F20")), E2.t90.iloc[-1], E2.O_peak.iloc[-1]))
e3 = E3.set_index("t-sign")
Pp("Speed matters less than size. For Sail, contracting over 3 years energizes 90%% by year %.2f; over 20 years only %.0f MW is energized by year 20. "
   "Cumulative net benefit is highest at moderate speed (t-sign 5 to 7.5): faster build-outs raise peak opposition and the early cost dip, while slow ones "
   "delay revenue past the horizon. Across the E4 grid (Figure 5, left) the best cell is %.0f MW at t-sign %g, and slow build-outs (t-sign 20) leave 18%% to 31%% "
   "of capacity unbuilt at year 20." % (e3.loc[3].t90, e3.loc[20].E20, E4.loc[E4.cum_nb.idxmax(), "size-mw"], E4.loc[E4.cum_nb.idxmax(), "t-sign"]))
H2("6.4 When Is Development a Net Benefit? (Goal 2)")
Pp("Under base assumptions **there is no size threshold**: net benefit is positive at every size from 50 to 6,050 MW, because revenue, costs and "
   "opposition all scale with MW. Thresholds appear when a policy or an assumption changes the per-MW balance (Figure 5 right, Table 4).")
FIG2("nb_heatmap.png", "threshold_curves.png", 2.85, 3.55, "Figure 5. Left: E4 cumulative net benefit ($ thousand per household) over size and contracting period; positive in every cell. "
     "Right: cumulative net benefit against size under each policy; dots mark break-even sizes.")
rows = [("Size, evaporative cooling", "%s MW" % r(th("size (MW)", "evaporative"))), ("Size, evaporative + drought", "%s MW" % r(th("size (MW)", "evaporative + drought"))),
        ("Size, ratepayers pay for grid", "%s MW" % r(th("size (MW)", "ratepayers pay"))), ("Size, ratepayers pay + evaporative", "%s MW" % r(th("size (MW)", "ratepayers pay + evaporative"))),
        ("Size, worst combination (evap, ratepayer, 100% abatement, drought)", "%s MW" % r(th("size (MW)", "worst (evap"))),
        ("ql_cost at Sail (base 1,500)", "%s $/hh/yr per GW" % r(th("parameter ql_cost", "900"))), ("k_prox at Sail (base 0.02)", "%.3f per GW" % th("parameter k_prox", "900")),
        ("O0 at Sail (base 0.40)", "%.2f" % th("parameter O0", "900")), ("rev_per_MW at Sail (base 0.1115)", "$%.4fM per MW-yr" % th("parameter rev_per_MW", "900")),
        ("svc_cost_per_MW at Sail (base 0.005)", "$%.4fM per MW-yr" % th("parameter svc_cost_per_MW", "900"))]
T(["Condition", "Break-even value"], rows, "Table 4. Net benefit thresholds (cumulative net benefit = 0). NetLogo reruns at three of them give 0.00 $/household.", widths=[4.3, 2.0])
Pp("The physical thresholds are clear. Evaporative cooling makes development a net cost above about %s MW (%s MW in a drought), because above that "
   "size water demand exceeds the 27 MGD permit-capped supply and shortage costs and opposition outweigh revenue. Socializing grid costs makes it a net cost "
   "above about %s MW, just above the 3,500 MW all-four scenario. Under the worst policy mix even Sail is a net cost. The judgement thresholds are just as "
   "important: Sail is a net cost if the quality-of-life cost exceeds about $%s per household per GW, if the housing proximity premium exceeds about %.1f%% "
   "per GW, or if initial opposition exceeds about %.2f. All of these lie inside their plausible ranges. E10 (Figure 6) confirms that at the high value of "
   "k_prox, ql_cost or O0 net benefit is negative at every size." % (
       r(th("size (MW)", "evaporative")), r(th("size (MW)", "evaporative + drought")), r(th("size (MW)", "ratepayers pay")), r(th("parameter ql_cost", "900")),
       100 * th("parameter k_prox", "900"), th("parameter O0", "900")))
FIGR("e10_sign.png", 6.2, "Figure 6. E10: cumulative net benefit against size at low, base and high values of the four most influential ASSUMPTION parameters.")
H2("6.5 Policy Comparisons (Goal 3)")
FIGR("policy_comparison.png", 5.2, "Figure 7. E5-E8: cumulative net benefit per household for each policy setting at 900 MW and 3,500 MW.")
g = lambda e, **kw: run(e, **kw)  # noqa: E731
ev35, cl35 = g("E5", **{"size-mw": 3500, "cooling": "evap", "drought?": False}), g("E5", **{"size-mw": 3500, "cooling": "closed", "drought?": False})
evd35 = g("E5", **{"size-mw": 3500, "cooling": "evap", "drought?": True})
ev9 = g("E5", **{"size-mw": 900, "cooling": "evap", "drought?": False})
rp9, rp35 = g("E6", **{"size-mw": 900, "payer": "ratepayer"}), g("E6", **{"size-mw": 3500, "payer": "ratepayer"})
a0, a1 = g("E7", **{"size-mw": 900, "abate0": 0.0}), g("E7", **{"size-mw": 900, "abate0": 1.0})
wb9, ww9, wb35, ww35 = g("E8", case="best", **{"size-mw": 900}), g("E8", case="worst", **{"size-mw": 900}), g("E8", case="best", **{"size-mw": 3500}), g("E8", case="worst", **{"size-mw": 3500})
B(["**Cooling** is the policy with the largest effect at large size. At 3,500 MW evaporative cooling lifts peak water stress from %.2f to %.2f (%.2f in a drought) and turns cumulative net benefit from +$%s to $%s per household. At Sail's size it costs $%s but stays positive (+$%s)." % (
    cl35.stress_peak, ev35.stress_peak, evd35.stress_peak, r(cl35.cum_nb), r(ev35.cum_nb), r(E1.cum_nb - ev9.cum_nb), r(ev9.cum_nb)),
   "**Grid payer:** socializing upgrades raises the rate index to %.4f at Sail and %.4f at 3,500 MW, which cuts cumulative net benefit by $%s and $%s per household. The PSC large-load rule is therefore worth most for the larger scenarios." % (
       rp9.RI_max, rp35.RI_max, r(E1.cum_nb - rp9.cum_nb), r(run("E6", **{"size-mw": 3500, "payer": "dc"}).cum_nb - rp35.cum_nb)),
   "**Abatement:** each 25 points of initial abatement costs Sail residents about $%s per household over 20 years (from +$%s with none to +$%s with 100%%). Abatement changes the size of the benefit but never flips its sign by itself." % (
       r((a0.cum_nb - a1.cum_nb) / 4), r(a0.cum_nb), r(a1.cum_nb)),
   "**Drought** alone matters little with closed-loop cooling (peak stress %.2f at 3,500 MW); it matters a great deal with evaporative cooling." % run("E5", **{"size-mw": 3500, "cooling": "closed", "drought?": True}).stress_peak,
   "**Combinations (E8):** the best mix (closed-loop, data centers pay, no abatement) gives +$%s at Sail and +$%s at 3,500 MW; the worst mix gives $%s and $%s." % (
       r(wb9.cum_nb), r(wb35.cum_nb), r(ww9.cum_nb), r(ww35.cum_nb))])
H2("6.6 Cross-Sector Feedback (Goal 4) and Sensitivity")
FIGR("feedback.png", 5.2, "Figure 8. E9: energized capacity with feedback on and off (left) and the delay to 90% energization caused by opposition (right).")
Pp("Switching the opposition links off shows how much the feedback matters (Figure 8). With feedback on, opposition delays 90%% energization by "
   "%.2f to %.2f years and lowers year-20 net fiscal impact by %.1f%% to %.1f%%. The effect grows with size and with slower contracting, because a long "
   "construction period keeps opposition high: for 3,500 MW at t-sign 10, 90%% energization slips from year %.2f to %.2f and cumulative net benefit falls "
   "from $%s to $%s. For Sail at the base speed the difference is small (%.2f years). Opposition slows but never stalls build-out in these runs; the lowest "
   "permitting factor is %.2f, and every run reaches at least 98%% of its target by year 20. The reinforcing relief loop is visible too: after construction, "
   "large campuses end with lower opposition (%.2f at 3,500 MW) than Sail (%.2f)." % (
       d90.min(), d90.max(), 100 * dF.min(), 100 * dF.max(), off9.loc[(3500, 10)].t90, on9.loc[(3500, 10)].t90, r(off9.loc[(3500, 10)].cum_nb),
       r(on9.loc[(3500, 10)].cum_nb), d90.loc[(900, 5)], on9.m_min.min(), on9.loc[(3500, 5)].O20, on9.loc[(900, 5)].O20))
FIGR("tornado.png", 4.2, "Figure 9. One-at-a-time sensitivity of Sail's cumulative net benefit (55 parameters swept across their ranges; top 15 shown).")
Pp("The sensitivity analysis (Figure 9) sweeps all 55 parameters with a range. The five most influential are k_prox, ql_cost, rev_per_MW, O0 and abate0; "
   "%d parameters (%s) flip the sign of Sail's net benefit on their own. A Latin hypercube of 400 samples over the top eight ASSUMPTION parameters "
   "gives a positive cumulative net benefit in only %.0f%% of samples (5th to 95th percentile $%s to $%s). Peak water stress stays below 0.70 in every "
   "sample, so the water and rate results for Sail are robust; the sign of net benefit is not." % (
       len(flips), ", ".join(flips), 100 * lhs_pos, r(LHS.cum_nb.quantile(0.05)), r(LHS.cum_nb.quantile(0.95))))

# ------------------------------------------------------------------ 7 conclusions
H1("7. Conclusions")
B(["**Sail as designed is a modest net benefit, conditional on judgement values.** With closed-loop cooling and data centers paying for their grid, Sail adds about $%s million to county and school finances over 20 years and barely moves rates or water stress. Residents come out ahead by about $%s per household, but only after about %.0f years, and only if quality-of-life and housing costs are near the assumed values." % (r(F["F20"]), r(F["cum"]), F["payback"]),
   "**Physical design and cost allocation decide the large scenarios.** Size alone does not create a net cost. Evaporative cooling (net cost above about %s MW) and socialized grid costs (above about %s MW) do. The county's strongest levers are therefore cooling and water terms in the zoning conditions and support for the PSC large-load rule, more than abatement level." % (
       r(th("size (MW)", "evaporative")), r(th("size (MW)", "ratepayers pay"))),
   "**Feedback matters most for large, slow build-outs.** Opposition delays energization by up to about three years and cuts revenue by up to about 12%, but in no realistic case does it stop a project.",
   "**Fiscal gains are not the same as resident benefit.** In configuration 2 the county gains over $3 billion in net fiscal impact while residents are about $26,000 per household worse off.",
   "**What I learned:** a delay cascade is needed to represent grid lag correctly; generating the NetLogo model from one specification and checking it against an independent implementation caught errors early; and the honest answer to a policy question can be \"it depends on these specific values\", which sensitivity analysis makes explicit."])
Pp("**Limitations.** The net benefit indicator is a value-weighted index: it treats housing cost increases as a cost to all households, although homeowners "
   "gain equity, and it is undiscounted. The quality-of-life and housing weights cannot be measured from public data. Several inputs are secondary sources "
   "or assumptions (the county tax digest, current water demand, Georgia Power residential revenue, Pegasus size, Sail's actual abatement terms). Each "
   "campus is a single aggregate with one build schedule. Electricity generation, regional water planning and the appeal and referendum outcomes are outside the model.")

# ------------------------------------------------------------------ 8 future work
H1("8. Future Work")
B(["Replace the main assumptions with local data: the county digest and levy, the water authority's current demand, Georgia Power's large-load contracts and Sail's abatement agreement.",
   "Estimate the housing and quality-of-life weights from a survey or from property sales near existing Georgia data centers.",
   "Model each campus and building separately with its own schedule, and add discounting and a distributional view (owners, renters, nearby residents).",
   "Add regional links: power generation additions and their emissions, and the Metropolitan North Georgia water plan.",
   "Add the legal and political process (appeal, referendum, moratorium) as discrete events that can halt or reverse permitting."])

# ------------------------------------------------------------------ AI disclosure
H1("9. Disclosure of AI Use")
Pp("AI tools were used extensively, and every use was logged in ai_use_log.md. I defined the topic, scope, goals and model structure in the approved "
   "proposal and made the final modeling choices. Claude Code (Anthropic) helped draft the execution plan, searched the web for public sources (each "
   "recorded with a URL and labeled verified or secondary), and wrote the model specification, the Python reference model and tests, the NetLogo model "
   "generator and the model comparison. Devin CLI (Cognition) ran and debugged the validation tests, wrote the sensitivity, experiment, findings, "
   "figure and snapshot scripts, and drafted this report and the slides from the generated results. Every number in this report is read from model "
   "output files by the report build script, and every factual claim was checked against data/sources.md (notes/factcheck.md). I reviewed the "
   "deliverables before submission.")

# ------------------------------------------------------------------ references
p = doc.add_paragraph()
p.add_run().add_break(WD_BREAK.PAGE)
H1("References")
refs = [
    "U.S. Census Bureau, \"QuickFacts: Coweta County, Georgia,\" https://www.census.gov/quickfacts/cowetacountygeorgia (accessed Nov. 23, 2026).",
    "WaterWorld, \"Coweta County opens a new chapter for Chattahoochee River water supply,\" and Georgia EPD draft permit notice 038-0005, https://www.waterworld.com/top-projects/article/55412711/ (accessed Nov. 23, 2026).",
    "Georgia Public Service Commission, \"Media advisory: data centers rule,\" Jan. 23, 2025, https://psc.ga.gov/site/assets/files/8617/media_advisory_data_centers_rule_1-23-2025.pdf.",
    "Chattahoochee Riverkeeper, \"Project Sail Fact Sheet,\" Mar. 2026, https://chattahoochee.org/wp-content/uploads/2026/03/Project-Sail-Fact-Sheet-March-2026.pdf.",
    "Economic Impact Group, \"Project Sail Fiscal Impact Analysis (21 years),\" prepared for Prologis, Sept. 2025, https://assets.foleon.com/eu-central-1/de-uploads-7e3kk3/52091/project_sail_fiscal_impact_analysis_-_21_years_-_final.25ead91146c8.pdf.",
    "Atlanta Journal-Constitution, \"Coweta votes to turn this 800-acre forest into $17B data center campus,\" Apr. 2026, https://www.ajc.com/business/2026/04/coweta-votes-to-turn-this-800-acre-forest-into-17b-data-center-campus.",
    "Chattahoochee Riverkeeper, \"Project Sail Fact Sheet,\" Jan. 2025, https://chattahoochee.org/wp-content/uploads/2025/01/Project-Sail-Fact-Sheet-January-2025.pdf.",
    "The Citizen, \"Coweta residents sue to block Project Sail data center,\" May 11, 2026, https://thecitizen.com/2026/05/11/coweta-residents-sue-to-block-project-sail-data-center/.",
    "WSB-TV, \"Thousands of Georgia voters push first-of-its-kind election on data centers,\" 2026, https://www.wsbtv.com/news/local/thousands-georgia-voters-push-first-of-its-kind-election-data-centers/GJ246S2AGZF2ZFLKFVVN7BFQ3A/.",
    "Baxtel, \"Bridgeport Data Center Campus (Coweta),\" https://baxtel.com/data-center/bridgeport-data-center-campus-coweta (accessed Nov. 23, 2026).",
    "Cleanview, \"Project Peach,\" https://cleanview.co/data-centers/georgia/project-peach-2015 (accessed Nov. 23, 2026).",
    "FOX 5 Atlanta, \"Douglas County leaders just killed massive data center project,\" https://www.fox5atlanta.com/news/douglas-county-leaders-just-killed-massive-data-center-project (accessed Nov. 23, 2026).",
    "The Spokesman-Review (AP), \"Their water taps ran dry when Meta built next door,\" July 19, 2025, https://www.spokesman.com/stories/2025/jul/19/their-water-taps-ran-dry-when-meta-built-next-door.",
    "A. Shehabi et al., \"2024 United States Data Center Energy Usage Report,\" Lawrence Berkeley National Laboratory, LBNL-2001637, Dec. 2024.",
    "U. Wilensky, NetLogo, Center for Connected Learning and Computer-Based Modeling, Northwestern University, 1999; version 7.0.4 used.",
    "J. D. Sterman, Business Dynamics: Systems Thinking and Modeling for a Complex World. Boston: Irwin/McGraw-Hill, 2000.",
]
for i, ref in enumerate(refs, 1):
    q = doc.add_paragraph()
    q.paragraph_format.left_indent = Inches(0.35)
    q.paragraph_format.first_line_indent = Inches(-0.35)
    runs(q, "[%d] %s" % (i, ref), size=12)


def to_pdf(docx_path, pdf_path):
    ps = ("$w = New-Object -ComObject Word.Application; $w.Visible = $false; "
          "$d = $w.Documents.Open('%s'); $d.SaveAs([ref]'%s', [ref]17); $d.Close(); $w.Quit()" % (docx_path, pdf_path))
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True)


def check_pdf(pdf_path):
    from pypdf import PdfReader
    rd = PdfReader(pdf_path)
    texts = [pg.extract_text() or "" for pg in rd.pages]
    ref_page = [i for i, t in enumerate(texts) if t.strip().startswith("References")][-1]
    body = ref_page - 1  # pages 2 .. ref_page (1-based) are body; cover is page 1
    fonts = set()
    for pg in rd.pages:
        res = pg.get("/Resources") or {}
        for f in (res.get("/Font") or {}).values():
            fonts.add(str(f.get_object().get("/BaseFont")))
    return len(rd.pages), body, fonts


if __name__ == "__main__":
    dx, pdf = os.path.abspath(OUT + ".docx"), os.path.abspath(OUT + ".pdf")
    doc.save(dx)
    to_pdf(dx, pdf)
    n, body, fonts = check_pdf(pdf)
    print("pages %d, body pages (excluding cover and references) %d, fonts %s" % (n, body, sorted(fonts)))
    if not 10 <= body <= 12:
        print("WARNING: body length outside 10-12 pages")
