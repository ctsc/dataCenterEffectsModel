"""Plan Step 9: build slides/FinalProject_2026_CTierney.pptx (16:9, about 6 minutes, speaker notes on every slide).

Numbers come from experiments/*.csv at build time. Rendering check: PowerPoint (COM) exports every slide to
slides/render/*.png, and the script checks that no text box runs past the slide edge.
Run: python slides/build_slides.py
"""
import os
import subprocess
import sys

import pandas as pd
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
FIG, EXP = os.path.join(ROOT, "figures"), os.path.join(ROOT, "experiments")
OUT = os.path.join(HERE, "FinalProject_2026_CTierney.pptx")
INK, BLUE, ORANGE, GREY = RGBColor(0x1F, 0x29, 0x33), RGBColor(0x00, 0x72, 0xB2), RGBColor(0xD5, 0x5E, 0x00), RGBColor(0x55, 0x5F, 0x6B)
FONT = "Calibri"

S = pd.read_csv(os.path.join(EXP, "summary_runs.csv"))
TH = pd.read_csv(os.path.join(EXP, "thresholds.csv"))


def run(exp, **kw):
    q = S[S.experiment == exp]
    for k, v in kw.items():
        q = q[q[k] == v]
    return q.iloc[0]


def th(kind, pre):
    return float(TH[(TH.kind == kind) & TH.condition.str.startswith(pre)].value.iloc[0])


E1 = run("E1")
r = lambda x: "{:,.0f}".format(x)  # noqa: E731
ev35 = run("E5", **{"size-mw": 3500, "cooling": "evap", "drought?": True})
cl35 = run("E5", **{"size-mw": 3500, "cooling": "closed", "drought?": True})
e9 = S[S.experiment == "E9"]
on, off = e9[e9["links-on?"] == True].set_index(["size-mw", "t-sign"]), e9[e9["links-on?"] == False].set_index(["size-mw", "t-sign"])  # noqa: E712
d90 = (on.t90 - off.t90)

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
BLANK = prs.slide_layouts[6]


def text(slide, x, y, w, h, paras, size=20, color=INK, bold_first=False, align=PP_ALIGN.LEFT):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    for i, ptxt in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        p.space_after = Pt(8)
        for j, part in enumerate(ptxt.split("**")):
            if not part:
                continue
            rr = p.add_run()
            rr.text = part
            rr.font.size, rr.font.name, rr.font.color.rgb = Pt(size), FONT, color
            rr.font.bold = (j % 2 == 1) or (bold_first and i == 0)
    return tb


def slide(title, notes, kicker=None):
    s = prs.slides.add_slide(BLANK)
    text(s, 0.5, 0.3, 12.3, 0.8, [title], size=32, color=INK).text_frame.paragraphs[0].runs[0].font.bold = True
    if kicker:
        text(s, 0.5, 1.05, 12.3, 0.5, [kicker], size=18, color=BLUE)
    s.notes_slide.notes_text_frame.text = notes
    return s


def pic(s, name, x, y, w=None, h=None):
    kw = {}
    if w:
        kw["width"] = Inches(w)
    if h:
        kw["height"] = Inches(h)
    return s.shapes.add_picture(os.path.join(FIG, name), Inches(x), Inches(y), **kw)


def bullets(s, x, y, w, h, items, size=20):
    return text(s, x, y, w, h, ["\u2022  " + i for i in items], size=size)


# 1 title
s = prs.slides.add_slide(BLANK)
text(s, 0.8, 2.0, 11.7, 1.6, ["Data Centers and a Growing County"], size=44).text_frame.paragraphs[0].runs[0].font.bold = True
text(s, 0.8, 3.2, 11.7, 1.0, ["A system dynamics model of data center development in Coweta County, Georgia"], size=26, color=BLUE)
text(s, 0.8, 4.6, 11.7, 1.4, ["Carter Tierney", "CSC 8840 Final Project, Option 2  |  Dr. Xiaolin Hu  |  Fall 2026"], size=20, color=GREY)
s.notes_slide.notes_text_frame.text = ("About 15 seconds. My project asks whether data center development is good or bad for the residents of a fast-growing county, "
                                       "using Coweta County's Project Sail as the base case, and which choices change the answer.")

# 2 problem and context
s = slide("Problem: is a data center a net benefit to residents?",
          "About 50 seconds. Coweta approved Project Sail 3-2 in April 2026: Prologis, nine buildings, about 900 MW, closed-loop cooling, "
          "about 300,000 gallons per day, and a projected $100 million a year in taxes. It is still contested by an appeal and a referendum petition, "
          "and three more proposals would take the county to 3,500 MW. Tax revenue, electricity, water, housing and opposition all interact over "
          "years, which is why I used system dynamics.",
          "Project Sail: approved 3-2 in April 2026, still contested")
bullets(s, 0.6, 1.8, 6.4, 5.2, ["**Project Sail** (Prologis): 9 buildings, about 900 MW, closed-loop air cooling, about 300,000 gal/day, about $100M/yr tax at full build-out",
                                "Larger scenarios: + Bridgeport (1,500 MW) + Pegasus (400 MW, assumed) = 2,800 MW; + Peach (700 MW) = 3,500 MW",
                                "Coweta: 160,240 residents (2025), 27 MGD water permit, Georgia Power under a 2025 PSC large-load rule",
                                "Effects play out over years and feed back on each other: **a system dynamics question**"], size=20)
text(s, 7.4, 1.9, 5.4, 4.8, ["**Goals**", "1. Size and speed effects on rates, water, finances, housing", "2. When is it a net benefit or net cost?",
                             "3. Policies: cooling, grid payer, abatement, drought", "4. How much does opposition feedback matter?",
                             "5. Validate (units, extremes, dt, counties, sensitivity)"], size=19)

# 3 model structure
s = slide("Model: 4 sectors, 6 stocks, 4 feedback loops",
          "About 60 seconds. The six stocks from the proposal are energized MW, grid MW, water capacity, cumulative net fiscal impact, population and opposition, "
          "plus contracted load so that the grid can lag it. B1: grid follows contracted load after two years and caps energization. B2: water stress triggers "
          "expansion after five years, up to the 27 MGD permit. R1: tax revenue funds property tax relief, which lowers opposition. B3: construction, water "
          "stress, rates and housing raise opposition, which slows permitting. Net benefit is dollars per household per year against the no-data-center baseline.",
          "NetLogo 7 SD Modeler; Euler dt = 0.125 year, 20-year runs; every constant sourced or labeled ASSUMPTION")
pic(s, "causal_loop.png", 0.4, 1.65, w=7.6)
bullets(s, 8.2, 1.7, 4.8, 5.4, ["**B1** grid follows contracted load (2-yr delay), caps energized MW",
                                "**B2** water stress > 0.85 triggers expansion (5-yr delay)",
                                "**R1** tax revenue -> property tax relief -> less opposition -> faster build-out",
                                "**B3** construction, water, rates, housing -> opposition -> slower permitting",
                                "**Net benefit** ($/household/yr vs no data center) = fiscal - electricity - housing - water - quality of life"], size=17)

# 4 experiment design + validation
s = slide("Experimental design and validation",
          "About 45 seconds. Validation came first and passed: a unit audit, ten extreme-condition tests in NetLogo, a time-step test where halving dt changes "
          "nothing by more than 0.4 percent, a comparison with Douglas and Newton counties, and sensitivity analysis. The NetLogo model also matches an independent "
          "Python implementation to 10 to the minus 12. Then eleven BehaviorSpace experiments, about 280 runs.",
          "Validation passed before any experiment; NetLogo matches an independent Python model to 5e-12")
rows = [("E0-E1", "baseline and Sail base case"), ("E2-E4", "size, speed, size x speed (49 runs)"), ("E5-E8", "cooling x drought, grid payer, abatement, combinations"),
        ("E9", "opposition feedback on vs off (24 runs)"), ("E10", "top assumptions x 14 sizes (168 runs)")]
tb = s.shapes.add_table(len(rows) + 1, 2, Inches(0.6), Inches(1.8), Inches(6.6), Inches(3.4)).table
for j, h in enumerate(("Experiment", "What varies")):
    tb.cell(0, j).text = h
for i, (a, b) in enumerate(rows, 1):
    tb.cell(i, 0).text, tb.cell(i, 1).text = a, b
for row in tb.rows:
    for c in row.cells:
        for p in c.text_frame.paragraphs:
            for rr in p.runs:
                rr.font.size, rr.font.name = Pt(17), FONT
tb.columns[0].width, tb.columns[1].width = Inches(1.5), Inches(5.1)
bullets(s, 7.6, 1.8, 5.3, 5.0, ["Units audit: no mismatches", "10/10 extreme-condition tests pass", "dt 0.125 vs 0.0625: max change 0.40%",
                                "Revenue share 4.8-7.8% of county budget, inside Douglas County's 3-8%", "Water share brackets Newton County's 10%",
                                "Sensitivity: 55 parameters + Latin hypercube"], size=18)

# 5 base case
s = slide("Result 1: Sail is a modest net benefit, after a slow start",
          "About 50 seconds. Ninety percent of Sail is energized by year %.1f. Net fiscal impact reaches %s million dollars. Because data centers pay for their grid "
          "and cooling is closed-loop, rates and water barely move. Opposition peaks at %.2f during construction and falls as relief arrives. Residents lose money "
          "for the first years, and only come out ahead for good from about year %.0f; the 20-year total is about %s dollars per household." % (
              E1.t90, r(E1.F20), E1.O_peak, E1.payback_year, r(E1.cum_nb)),
          "Cumulative net benefit +$%s per household over 20 years; positive for good only from year %.0f" % (r(E1.cum_nb), E1.payback_year))
pic(s, "base_timeseries.png", 0.4, 1.6, h=5.7)
bullets(s, 9.15, 1.8, 3.9, 5.4, ["90%% energized by year %.1f" % E1.t90, "Net fiscal +$%sM by year 20" % r(E1.F20), "Rate index %.4f (DC pays)" % E1.RI_max,
                                 "Peak water stress %.2f" % E1.stress_peak, "Opposition peak %.2f, then %.2f" % (E1.O_peak, E1.O20)], size=18)

# 6 thresholds and policies
s = slide("Results 2-3: design and cost sharing, not size, flip the sign",
          "About 60 seconds. Under base assumptions there is no size threshold: everything scales with megawatts, so bigger is just more. The sign flips "
          "when the per-megawatt balance changes: evaporative cooling makes it a net cost above about %s MW, socialized grid costs above about %s MW, and the "
          "worst policy mix above about %s MW. At 3,500 MW in a drought, evaporative cooling gives minus %s dollars per household, closed-loop gives plus %s." % (
              r(th("size (MW)", "evaporative")), r(th("size (MW)", "ratepayers pay")), r(th("size (MW)", "worst (evap")), r(-ev35.cum_nb), r(cl35.cum_nb)),
          "No size threshold under base policy; break-even sizes appear with evaporative cooling or socialized grid costs")
pic(s, "threshold_curves.png", 0.3, 1.6, h=5.6)
bullets(s, 9.7, 1.8, 3.4, 5.4, ["Evaporative: net cost above **%s MW**" % r(th("size (MW)", "evaporative")),
                                "Ratepayers pay grid: above **%s MW**" % r(th("size (MW)", "ratepayers pay")),
                                "Worst mix: above **%s MW**" % r(th("size (MW)", "worst (evap")),
                                "Abatement changes size of benefit, never its sign"], size=18)

# 7 feedback + sensitivity
s = slide("Result 4: feedback matters for large build-outs",
          "About 50 seconds. With opposition feedback on, large slow build-outs take up to %.1f more years to reach 90 percent, but nothing stalls. "
          "The honest caveat: the sign of Sail's net benefit depends on judgement parameters. If the quality-of-life cost is above about %s dollars per GW, the "
          "housing premium above %.1f percent per GW, or initial opposition above %.2f, Sail is a net cost. In a Latin hypercube it is positive in about half the samples." % (
              d90.max(), r(th("parameter ql_cost", "900")), 100 * th("parameter k_prox", "900"), th("parameter O0", "900")),
          "Opposition adds up to %.1f years to 90%% energization but never stalls a project" % d90.max())
pic(s, "feedback.png", 0.3, 1.6, w=6.6)
pic(s, "tornado.png", 7.0, 1.6, w=6.1)
text(s, 0.5, 5.75, 12.3, 1.4, ["Sail breaks even at ql_cost **%s** (base 1,500), k_prox **%.3f** (base 0.02) or O0 **%.2f** (base 0.40): all inside their plausible ranges." % (
    r(th("parameter ql_cost", "900")), th("parameter k_prox", "900"), th("parameter O0", "900"))], size=18, color=ORANGE)

# 8 conclusions, future work, AI disclosure
s = slide("Conclusions, future work and AI disclosure",
          "About 40 seconds. The county's strongest levers are cooling and water terms and making data centers pay for grid upgrades, more than abatement. "
          "Fiscal gains are not the same as resident benefit. Next steps are local data for the assumptions and a survey for the quality-of-life weights. "
          "AI tools, Claude Code and Devin, helped with research, code, figures and drafting; every use is logged, every number comes from model output, and I reviewed everything.")
bullets(s, 0.6, 1.4, 6.3, 5.8, ["Sail as designed: modest net benefit (+$%s/household), conditional on judgement values" % r(E1.cum_nb),
                                "Strongest county levers: **cooling/water terms** and **data centers paying for the grid**",
                                "Fiscal gain is not resident benefit: 3,500 MW evaporative in drought gives +$3.0B fiscal but %s $/household" % r(ev35.cum_nb),
                                "Limitations: value-weighted index, undiscounted, several secondary or assumed inputs"], size=19)
bullets(s, 7.2, 1.4, 5.7, 3.2, ["**Future work:** local digest, water and utility data; survey-based weights; per-building schedules; legal events (appeal, referendum)"], size=18)
bullets(s, 7.2, 4.0, 5.7, 3.2, ["**AI use:** Claude Code and Devin CLI assisted with research, code, figures and drafting. All uses logged (ai_use_log.md); results generated from model output; reviewed by me"], size=18)

prs.save(OUT)


def render():
    out = os.path.join(HERE, "render")
    os.makedirs(out, exist_ok=True)
    ps = ("$p = New-Object -ComObject PowerPoint.Application; $d = $p.Presentations.Open('%s', $true, $false, $false); "
          "$d.Export('%s', 'PNG', 1600, 900); $d.Close(); $p.Quit()" % (os.path.abspath(OUT), os.path.abspath(out)))
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True)
    return sorted(os.listdir(out))


def overflow():
    bad = []
    for i, s in enumerate(Presentation(OUT).slides, 1):
        for sh in s.shapes:
            if sh.left + sh.width > prs.slide_width + 10 or sh.top + sh.height > prs.slide_height + 10:
                bad.append((i, sh.name))
    return bad


if __name__ == "__main__":
    print("slides:", len(prs.slides), "rendered:", render())
    print("shapes past the slide edge:", overflow() or "none")
    sys.exit(0)
