# notes/demo_script.md: live demo (about 6 minutes)

Model: `model/DataCenterSD.nlogox` in NetLogo 7.0.4. Every number below was produced by the model itself (experiments E1, E5, E9; snapshots `figures/snapshot_1.png` and `figures/snapshot_2.png`). Before class, open the model once, then rehearse this script end to end.

## Before you start (about 20 s)

- Open the model and show the Interface tab. Mention that every parameter slider on the right comes from `data/parameters.csv` (sourced or labeled ASSUMPTION).
- Optional, 15 s: Tools > System Dynamics Modeler shows the stock-and-flow diagram (8 stocks, 8 flows). Close it again.

## Configuration 1: Project Sail base case (about 2.5 min)

Settings: press **Sail only** (size-mw 900), t-sign 5, abate0 0.907, cooling **closed**, payer **dc**, drought? **off**, links-on? **on**. Press **setup**, then **go** (stops at year 20).

What to point at and say:
1. **Load (MW) plot:** contracted load is signed first, grid capacity follows about 2 years later, and energized capacity follows the grid. That is balancing loop B1: data centers cannot energize beyond the grid. 90% is energized by year 9.25.
2. **Opposition and permitting plot:** opposition rises from 0.40 to a peak of 0.51 around year 6 while construction is under way, which slows permitting (factor down to 0.76, loop B3). Once revenue arrives, property tax relief pulls opposition down to 0.35 (reinforcing loop R1).
3. **Water stress plot:** closed-loop cooling barely moves water stress (0.69 at year 20 against 0.68 with no data center).
4. **Net benefit plot:** per household it dips to about -246 $/yr around year 6. Construction costs and opposition arrive before the tax revenue, because abatement is high in the early years. It turns positive at year 10 and reaches 557 $/yr by year 20.
5. **Monitors at year 20:** net fiscal impact 812 $M; cumulative net benefit **+2,763 $ per household**.
6. One sentence of honesty: the sign depends on judgement values. If ql-cost is above about 2,024 or k-prox above about 0.035, Sail becomes a net cost (show the ql-cost slider, but do not rerun unless time allows).

## Configuration 2: all four campuses, evaporative cooling, drought (about 2.5 min)

Settings: press **+ Peach (all four)** (size-mw 3500), cooling **evap**, drought? **on**, everything else as in configuration 1. Press **setup**, then **go**.

What to point at and say:
1. **Water stress plot:** demand passes capacity at year 4.4 (stress above 1). The drought in years 8-10 spikes stress to 2.30. Supply expansion (loop B2) lifts capacity toward the 27 MGD permit cap after a 5-year delay, but the permit cap binds.
2. **Opposition and permitting plot:** opposition climbs to 0.77 around year 10, and the permitting factor falls to 0.15. Build-out slows but does not stop.
3. **Net benefit plot:** falls to about -3,400 $/household/yr during the drought and stays negative. Cumulative net benefit is **-25,953 $ per household**, even though net fiscal impact is +3,025 $M. That is the main lesson: fiscal gains do not guarantee a net benefit to residents.
4. Live contrast (30 s): switch cooling to **closed** (keep drought on), press setup and go. Peak water stress falls to 0.92 and cumulative net benefit becomes **+10,942**. The cooling choice flips the sign. The break-even size for evaporative cooling is about 1,458 MW (1,188 MW with drought).

## Optional, if time remains: feedback on vs off (about 1 min)

Settings: size-mw 3500, cooling closed, drought? off, t-sign **10**. Run with links-on? **on**, then **off**.
- With feedback on, 90% energization slips from year 12.6 to year 15.75, and cumulative net benefit drops from 10,217 to 6,801 $/household. Cross-sector feedback matters most for large, slow build-outs.

## Backup if the live demo fails

Show `figures/snapshot_1.png` and `figures/snapshot_2.png` (real NetLogo screenshots of configurations 1 and 2 at year 20) and `figures/base_timeseries.png`.
