# notes/model_spec.md

Single specification of the model. The Python reference model (`analysis/reference_model.py`), the NetLogo generator (`model/build_nlogox.py`) and the report all follow this file. Constants are in `data/parameters.csv`. Units: time in years, power in MW, water in MGD (million gallons per day), money in $ million unless noted. Integration is Euler with step dt.

## Scenario controls

| Control | Values | Default (base case) |
|---|---|---|
| `size` S (MW) | 0, 450, 900, 1800, 2800 (Sail+Bridgeport+Pegasus), 3500 (+Peach) | 900 (Sail only) |
| `t_sign` (years of contracting at full permitting speed) | 3 to 15 | calibrated (5) |
| `cooling` | closed (wi_closed), evap (wi_evap) | closed |
| `payer` | dc (share_dc_pays), ratepayer (share_ratepayer_pays) | dc |
| `abate0` | 0 to 1 | 0.907 |
| `drought?` | off, on (start, duration, severity) | off |
| `links_on?` | true, false | true |

## State variables (stocks)

| Stock | Symbol | Unit | Initial |
|---|---|---|---|
| Energized data center capacity | E | MW | 0 |
| Grid capacity added for data centers | G | MW | 0 |
| Contracted load (supporting stock, see D5) | C | MW | 0 |
| Water supply capacity | W | MGD | W0 |
| Cumulative county net fiscal impact | F | $ million | 0 |
| Population | P | people | P0 |
| Community opposition | O | 0-1 | O0 |

## Equations (evaluated each step in this order, then stocks updated together)

Reference paths (no data center):
- P_base(t) = P0 * (1 + g_pop * dt)^(t / dt)   (the Euler baseline path, so the no-data-center run matches it exactly)
- H_ref(t) = (P_base(t) / P0)^hou_elast

**Opposition and permitting**
- constr = (C - E) / 1000 (GW under construction)
- m = clip((1 - s_perm * O) / (1 - s_perm * O0), 0, m_max) if links_on else 1

**Electricity and grid (balancing loop B1: grid follows contracted load; E cannot exceed G)**
- sign_rate = min(S / t_sign * m, max(0, S - C) / dt)   [MW/yr]
- dC/dt = sign_rate
- dG/dt = (C - G) / D_grid
- E_flow = (G - E) / tau_energize   [MW/yr]
- dE/dt = E_flow
- capex_annual = G * cost_per_MW * carry_charge   [$M/yr]
- share = share_ratepayer_pays if payer = ratepayer else share_dc_pays
- RI = 1 + share * capex_annual / resid_rev_base   (electricity rate index)

**Water (balancing loop B2: stress triggers expansion after a delay)**
- demand_base = water_base0 * P / P0
- demand = demand_base + E * wi   (wi = wi_closed or wi_evap)
- drought_on(t) = 1 if drought? and drought_start <= t < drought_start + drought_duration else 0
- W_eff = W * (1 - drought_severity * drought_on)
- water_stress = demand / W_eff
- stress_struct = demand / W
- W_target = demand / ws_target
- dW/dt = min(max(0, W_target - W), water_cap - W) / D_water if stress_struct > ws_trigger and W < water_cap else 0

**Population and housing**
- hx = H / H_ref - 1, where H = (P / P0)^hou_elast * (1 + k_prox * E / 1000)   (housing cost index; housing_cost_index = H)
- persons_per_MW = jobs_per_MW * (1 + job_multiplier) * newhh_per_job * hh_size
- dP/dt = P * g_pop * max(0, 1 - s_hm * hx) + persons_per_MW * E_flow

**County finance (reinforcing loop R1: tax revenue funds relief, lowering opposition and speeding build-out)**
- abate(t) = abate0 * max(0, 1 - t / T_abate)
- rev_net = rev_per_MW * E * (1 - abate(t))   [$M/yr]
- relief_cash = relief_share * rev_net
- R = relief_cash / levy_base   (relief index)
- cost_svc = svc_cost_per_MW * E
- pop_dc = P - P_base(t)
- cost_pop = percap_cost * pop_dc / 1e6
- dF/dt = rev_net - relief_cash - cost_svc - cost_pop

**Opposition (balancing loop B3 through m)**
- D = d_open0 + a_c * constr + a_w * max(0, water_stress - ws_opp) + a_e * (RI - 1) / 0.1 + a_h * hx - a_r * R
- O_star = max(0, D) / (1 + max(0, D))
- dO/dt = (O_star - O) / tau_O

## Net benefit indicator (one definition; $ per household per year, scenario minus no-data-center baseline)

- HH = P / hh_size
- fiscal_hh = 1e6 * (rev_net - cost_svc - cost_pop) / HH   (net public revenue, returned as relief or retained)
- elec_hh = (RI - 1) * elec_price / 100 * hh_kwh
- house_hh = hx * house_cost_base
- water_hh = shortage_cost * (max(0, water_stress - 1) - max(0, stress_base_eff(t) - 1))
  where stress_base_eff(t) = water_base0 * (P_base(t) / P0) / (W0 * (1 - drought_severity * drought_on(t))), so the baseline suffers the same drought and only the data center's added stress is charged
- ql_hh = ql_cost * (E / 1000) * O
- **nb = fiscal_hh - elec_hh - house_hh - water_hh - ql_hh**
- Cumulative net benefit = sum of nb * dt over the horizon ($ per household, undiscounted). Positive means a net benefit to residents.

All weights (shortage_cost, house_cost_base, ql_cost) are ASSUMPTIONS and are included in sensitivity analysis.

## Loops (for the diagram)

- **R1** reinforcing: E -> tax revenue -> relief -> lower opposition -> higher permitting speed m -> faster signing -> E.
- **B1** balancing: contracted load C -> grid capacity G (delay D_grid) -> E (E <= G).
- **B2** balancing: demand -> water stress -> expansion of W after D_water -> lower stress.
- **B3** balancing: construction (C - E), water stress, rate index, housing excess -> opposition -> lower m -> slower signing.

## Outputs recorded (per step)

year, E, G, C, W, F, P, O, water_stress, RI, H, hx, m, rev_net, relief_cash, cost_svc, cost_pop, nb, cum_nb.
